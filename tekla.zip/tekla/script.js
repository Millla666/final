let round = 0;

function shuffleAndReduce() {
    const container = document.getElementById('grid-container');
    let boxes = Array.from(container.children);
    
    if (round === 0) {
        // Shuffle boxes ensuring different colors are adjacent
        boxes = shuffle(boxes);
        while (!isValidShuffle(boxes)) {
            boxes = shuffle(boxes);
        }
    } else {
        // Halve the number of boxes
        const half = Math.ceil(boxes.length / 2);
        boxes = boxes.slice(0, half);
    }
    
    // Clear the grid and append new boxes
    container.innerHTML = '';
    boxes.forEach(box => container.appendChild(box));
    
    round++;
}

function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

function isValidShuffle(boxes) {
    const gridSize = Math.sqrt(boxes.length);
    for (let i = 0; i < boxes.length; i++) {
        const row = Math.floor(i / gridSize);
        const col = i % gridSize;
        const currentBox = boxes[i];
        
        const rightBox = col < gridSize - 1 ? boxes[i + 1] : null;
        const bottomBox = row < gridSize - 1 ? boxes[i + gridSize] : null;
        
        if ((rightBox && currentBox.className === rightBox.className) || 
            (bottomBox && currentBox.className === bottomBox.className)) {
            return false;
        }
    }
    return true;
}

